export default function getWindowScrollBarX(element: Element): number;
