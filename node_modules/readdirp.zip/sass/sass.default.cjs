require('./sass.dart.js');
const library = globalThis._cliPkgExports.pop();
if (globalThis._cliPkgExports.length === 0) delete globalThis._cliPkgExports;
library.load({
  immutable: require("immutable"),
});

module.exports = library;
