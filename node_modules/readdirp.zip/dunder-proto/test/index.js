'use strict';

require('./get');
require('./set');
